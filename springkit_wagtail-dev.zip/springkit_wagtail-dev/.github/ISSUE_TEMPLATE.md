
> ٩(ᐛ)و Please follow this template when creating a new task. Delete all of those instructions as you go, starting here.

> 1. In the title field above, pick something descriptive so at a glance we roughly now what the task is about.

> 2. Here, describe the task further, explain why this is something we should do. Give necessary context.

---

> 3. For this to be completed, is there specific documentation related to this? Useful links? Please add them here as a list.

> 4. Are there any screenshots or other images that you could attach to make the task clearer? Please add them as well.

---

> 5. Then, on the right side of this editor,
> - If you know who will likely work on the task, assign them.
> - Use labels to classify what type of work is involved – discipline, size, priority, as you see fit.

----

> 6. Finally, if this is a bug report, please specify the following:

- What is occuring?
- Full stack trace if available.
- Under what circumstances?
- Steps to reproduce.
- What is the expected behaviour?
- Where is it occurring? (URL, browser, server)
- Screenshots?
- Any other context to provide?

> 7. That's it! Live long and prosper ヽ(⌐■_■)ノ♪♬
