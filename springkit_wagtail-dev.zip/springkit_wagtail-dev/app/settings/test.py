from .base import *

CACHE_MIDDLEWARE_SECONDS = 0


WAGTAILSEARCH_BACKENDS = {"default": {"BACKEND": "wagtail.search.backends.db"}}


EMAIL_BACKEND = "django.core.mail.backends.console.EmailBackend"


# Analytics stuff
GOOGLE_TAG_MANAGER = False
GOOGLE_ANALYTICS_KEY = False
