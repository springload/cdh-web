from collections.abc import Iterable

from wagtail import blocks

from ..settings import get_setting
from ..utils.blocks import child_blocks

BlocksList = Iterable[tuple[str, blocks.Block], ...]


def get_default_blocks() -> BlocksList:
    return child_blocks(
        (
            "text",
            blocks.RichTextBlock(
                features=get_setting("SPRINGKIT_STANDARD_RICH_TEXT_FEATURES")
            ),
        ),
    )


class AccordionBlock(blocks.StructBlock):
    """
    A list of accordion items

    The blocks available in the body of each accordion item can be customised
    either by passing an iterable of (block_name, block) to the block, or by
    subclassing this block and setting the `body` property.
    """

    class Meta:
        template = "springkit/blocks/accordion/accordion.html"
        label = "Accordion"
        group = get_setting("BLOCK_GROUP_BODY_COPY")
        icon = "cogs"

    body = get_default_blocks()

    def __init__(self, local_blocks: BlocksList = None, **kwargs):
        if local_blocks:
            body = local_blocks
        else:
            body = self.body

        accordion_items = blocks.ListBlock(
            blocks.StructBlock(
                [
                    (
                        "heading",
                        blocks.CharBlock(
                            verbose_name="Accordion Title", required=True, max_length=80
                        ),
                    ),
                    (
                        "short_description",
                        blocks.CharBlock(
                            max_length=250,
                            required=False,
                            verbose_name="Short Description",
                        ),
                    ),
                    (
                        "body",
                        blocks.StreamBlock(
                            body,
                            required=True,
                        ),
                    ),
                ]
            )
        )
        super().__init__(
            local_blocks=(("accordion_items", accordion_items),),
            **kwargs,
        )
