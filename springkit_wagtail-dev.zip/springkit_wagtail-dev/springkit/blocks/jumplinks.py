from wagtail import blocks

from ..settings import get_setting

if get_setting("JUMPLINKS_ENABLED"):

    class JumplinkMixin(blocks.StructBlock):
        show_in_jumplinks = blocks.BooleanBlock(
            required=False,
            default=False,
            help_text=(
                "Link to this block in the jumplinks list "
                "(when 'Show jumplinks' is enabled in Page settings)"
            ),
        )

else:

    class JumplinkMixin(blocks.StructBlock):
        pass
