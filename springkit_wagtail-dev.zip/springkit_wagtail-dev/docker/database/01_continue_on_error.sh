psql+=( -v ON_ERROR_STOP=0 )
