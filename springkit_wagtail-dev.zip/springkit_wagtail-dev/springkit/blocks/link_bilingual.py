from wagtail import blocks

from ..settings import get_setting

LABEL_EN = "English language link text"
LABEL_MI = "Te reo Māori link text"


class BilingualLinkText(blocks.StructBlock):
    def __init__(self, local_blocks=None, required_langs=..., **kwargs):
        """
        This block's fields get set using local_blocks here so we can dynamically set
        the required-ness for each lang.
        """
        required_langs = self.get_required_langs(required_langs)
        local_blocks = (
            (
                "link_text_en",
                blocks.CharBlock(label=LABEL_EN, required="en" in required_langs),
            ),
            (
                "link_text_mi",
                blocks.CharBlock(label=LABEL_MI, required="mi" in required_langs),
            ),
        )
        super().__init__(local_blocks=local_blocks, **kwargs)

    def get_required_langs(self, required_langs) -> list[str | None, ...]:
        """
        Return a list of mandatory languages in link text fields
        """
        default_required = get_setting("BILINGUAL_LINKS_REQUIRED_LANGS")
        if required_langs is ...:
            required_langs = default_required
        if required_langs is None:
            required_langs = []
        return required_langs

    class Meta:
        label = "Link text"
        icon = "title"


class BilingualInternalLinkBlock(blocks.StreamBlock):
    """
    This block assumes page has Te reo title `title_mi` (provided by
    `BilingualTitlesMixin`).
    """

    page = blocks.PageChooserBlock()

    def __init__(self, local_blocks=None, required_langs=..., **kwargs):
        local_blocks = (
            (
                "link_text",
                BilingualLinkText(
                    required_langs=required_langs,
                    required=False,
                    help_text=(
                        "Override the link text taken from the target Page title fields"
                    ),
                ),
            ),
        )
        super().__init__(local_blocks, **kwargs)

    def get_context(self, value, parent_context=None):
        page = value.first_block_by_name("page").value
        if link_text := value.first_block_by_name("link_text"):
            text_en = link_text.value.get("link_text_en")
            text_mi = link_text.value.get("link_text_mi")
        else:
            text_en = page and page.title
            text_mi = page and getattr(page, "title_mi", "")
        link = {
            "url": page and page.get_url() or "#",
            "text_en": text_en,
            "text_mi": text_mi,
        }
        return super().get_context(link, parent_context)

    class Meta:
        template = "springkit/blocks/link/link_bilingual.html"
        label = "Internal link"
        icon = "link"
        max_num = 2
        block_counts = {
            "page": {"min_num": 1, "max_num": 1},
            "link_text": {"min_num": 0, "max_num": 1},
        }


class BilingualExternalLinkBlock(blocks.StreamBlock):
    link_url = blocks.URLBlock(label="URL")

    def __init__(self, local_blocks=None, required_langs=..., **kwargs):
        local_blocks = (
            ("link_text", BilingualLinkText(required_langs=required_langs)),
        )
        super().__init__(local_blocks, **kwargs)

    def get_context(self, value, parent_context=None):
        link_text = value.first_block_by_name("link_text").value
        text_en = link_text.get("link_text_en")
        text_mi = link_text.get("link_text_mi")
        link = {
            "url": value.first_block_by_name("link_url").value,
            "text_en": text_en,
            "text_mi": text_mi,
        }
        return super().get_context(link, parent_context)

    class Meta:
        template = "springkit/blocks/link/link_bilingual.html"
        label = "External link"
        icon = "link-external"
        max_num = 2
        block_counts = {
            "link_url": {"min_num": 1, "max_num": 1},
            "link_text": {"min_num": 1, "max_num": 1},
        }


class BilingualLinkBlock(blocks.StreamBlock):
    """
    Link block with English and Te reo text fields.

    The required-ness of each text field can be set project-wide using the
    `BILINGUAL_LINKS_REQUIRED_LANGS` setting (default: ["en"]) or as a parameter
    to the block:

    ("mi_link", BilingualLinkBlock(required_langs=["mi"]))
    ("any_link", BilingualLinkBlock(required_langs=None))

    If `BILINGUAL_LINKS` is True (default), then Springkit blocks with link
    fields will use this block.
    """

    def __init__(self, local_blocks=None, required_langs=..., **kwargs):
        local_blocks = (
            (
                "internal_link",
                BilingualInternalLinkBlock(required_langs=required_langs),
            ),
            (
                "external_link",
                BilingualExternalLinkBlock(required_langs=required_langs),
            ),
        )
        super().__init__(local_blocks=local_blocks, **kwargs)

    def render_basic(self, value, context=None):
        """Override to avoid <div> container"""
        return value[0].render(context=context)

    class Meta:
        label = "Link (bilingual)"
        group = get_setting("BLOCK_GROUP_LINKS_TILES")
        icon = "link"
        max_num = 1
