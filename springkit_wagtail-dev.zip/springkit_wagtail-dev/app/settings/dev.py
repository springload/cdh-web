from typed_environment_configuration import BoolVariable

from .base import *
from .grains.logging import DEV_LOGGING

SHOW_DEBUG_TOOLBAR = BoolVariable("DEV_SHOW_DEBUG_TOOLBAR", default=False).getenv()

LOGGING = DEV_LOGGING.copy()

ALLOWED_HOSTS = ("*",)

# "Dev catch all" property key by default in development
GOOGLE_ANALYTICS_KEY = "UA-40614522-2"

DEBUG = True

DEBUG_TOOLBAR_CONFIG = {
    "SHOW_TOOLBAR_CALLBACK": (
        lambda request: SHOW_DEBUG_TOOLBAR and not request.path.startswith("/admin")
    )
}

# Put emails into ./var/logs/emails folder
# EMAIL_BACKEND = 'django.core.mail.backends.filebased.EmailBackend'
# EMAIL_FILE_PATH = join(DJANGO_ROOT, 'var', 'logs', 'emails')
# or use console based email
EMAIL_BACKEND = "django.core.mail.backends.console.EmailBackend"

# As required by debug_toolbar
INTERNAL_IPS = ("10.0.2.2", "127.0.0.1")  # delila  # localhost

INSTALLED_APPS += (
    "debug_toolbar",
    "django_extensions",
)


INSTALLED_APPS = INSTALLED_APPS + ("wagtail.contrib.styleguide",)


MIDDLEWARE = [
    "debug_toolbar.middleware.DebugToolbarMiddleware",
] + MIDDLEWARE

CSRF_COOKIE_SECURE = False

# We don't need caching in dev, it just makes life hard
CACHE_MIDDLEWARE_SECONDS = 0

# https://docs.djangoproject.com/en/2.2/ref/settings/#secure-proxy-ssl-header
# configure django to recognise nginx-proxy doing ssl offloading
# Use this settings for local development only!!!
#   Can cause security issues on prod if misconfigured
SECURE_PROXY_SSL_HEADER = ("HTTP_X_FORWARDED_PROTO", "https")

TEMPLATES[0]["OPTIONS"]["loaders"] = [
    "django.template.loaders.filesystem.Loader",
    "django.template.loaders.app_directories.Loader",
]
