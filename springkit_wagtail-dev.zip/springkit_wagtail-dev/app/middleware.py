from logging import getLogger

from django.middleware.cache import UpdateCacheMiddleware

logger = getLogger(__name__)


class PreviewCompatibilityUpdateCacheMiddleware(UpdateCacheMiddleware):
    """
    A version of UpdateCacheMiddleware that allows you to
    *never* cache a dummy request regardless of other
    heuristics.
    Built to deal with a problem in Wagtail's preview
    function, that for some complicated reason would lead to
    the previews being cached in redis, but nowhere else
    Warning: This class may need to be updated for Django
    3.0, as the deprecation mixin for the base middleware
    will disappear
    """

    def process_response(self, request, response):
        if hasattr(request, "is_dummy") and request.is_dummy:
            logger.debug(
                "Skipping caching for path %s because request is a dummy", request.path
            )
            return response

        return super().process_response(request, response)
