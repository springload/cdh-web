function testFunc() {
  console.log('Why hello there, world');
}

testFunc();
