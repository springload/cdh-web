import re
from urllib import parse as url_parse

from django.forms.utils import ErrorList

from wagtail import blocks

from ..settings import get_setting

VIDEO_SERVICE_ID_REGEX = re.compile(
    r"(http:\/\/|https:\/\/|)(www.)?"
    r"(youtu(be\.com|\.be|be\.googleapis\.com))"
    r"\/(embed\/|watch\?v=|v\/)?"
    r"([A-Za-z0-9._%-]*)?"
)
YOUTUBE_URL_BASE = "https://www.youtube.com/embed"


def get_embed_url(video_url: str) -> str | None:
    embed_url = None
    if playlist_id := get_playlist_id(video_url):
        embed_url = (
            f"{YOUTUBE_URL_BASE}?listType=playlist&list={playlist_id}&enablejsapi=1"
        )
    elif video_id := VideoBlock.parse_video_id(video_url):
        embed_url = f"{YOUTUBE_URL_BASE}/{video_id}?enablejsapi=1"
    return embed_url


def get_playlist_id(video_url: str) -> str | None:
    """Youtube playlist ids are identified by 'list' param."""
    if not video_url:
        return
    parsed = url_parse.urlparse(video_url)
    url_params = dict(url_parse.parse_qsl(parsed.query))
    return url_params.get("list")


class VideoBlock(blocks.StructBlock):
    """
    Allows YouTube videos to be content managed.
    """

    class Meta:
        template = "springkit/blocks/video/video.html"
        label = "Video"
        group = get_setting("BLOCK_GROUP_MEDIA")
        icon = "media"

    VIDEO_SERVICE_YOUTUBE = "youtube"

    VIDEO_URL_ERROR = (
        "The video URL appears to be invalid, please check that you copied it "
        "in its entirety. Please enter a Youtube URL only, e.g. "
        "https://www.youtube.com/watch?v=DaRerbo6LOY for a single video, or "
        "https://www.youtube.com/watch?v=dQw4w9WgXcQ&list=PLetg744TF10BrdPjaEXf4EsJ1wz6fyf95"
        " for a playlist."
    )

    video = blocks.URLBlock(
        help_text="A YouTube URL. Link to a specifc video or playlist."
    )

    accessibility_description = blocks.CharBlock(
        help_text="Use this to describe the video. It is used as an accessibility attribute mainly for screen readers.",
        required=False,
    )

    transcript = blocks.RichTextBlock(
        features=get_setting("SPRINGKIT_SIMPLE_RICH_TEXT_FEATURES"),
        required=False,
    )

    def get_context(self, value, parent_context=None):
        context = super().get_context(value, parent_context)
        context["video_embed_url"] = get_embed_url(value.get("video"))
        context["video_service"] = self.VIDEO_SERVICE_YOUTUBE
        return context

    @classmethod
    def parse_video_id(cls, video_url):
        """
        Retrieves the ID from a YouTube.

        To tweak or edit the regex you can do so at
        https://regex101.com/r/gdJ0pt/5

        Supported URL structures:
        http://www.youtube.com/watch?v=0zM3nApSvMg&feature=feedrec_grec_index
        http://www.youtube.com/v/0zM3nApSvMg?fs=1&amp;hl=en_US&amp;rel=0
        https://www.youtube.com/watch?v=0zM3nApSvMg#t=0m10s
        http://www.youtube.com/embed/0zM3nApSvMg?rel=0
        http://www.youtube.com/watch?v=0zM3nApSvMg
        http://youtu.be/0zM3nApSvMg
        https://youtube.googleapis.com/v/My2FRPA3Gf8

        :param video_url:
        :return:
        """
        m = VIDEO_SERVICE_ID_REGEX.search(video_url)
        if m and m.group(6):
            return m.group(6)

    def clean(self, value):
        value = super().clean(value)
        video_url = value.get("video")
        video_id = get_playlist_id(video_url) or self.parse_video_id(video_url)
        if not video_id:
            raise blocks.StreamBlockValidationError(
                block_errors={"video": ErrorList([self.VIDEO_URL_ERROR])},
            )

        return value
