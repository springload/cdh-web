### Design
The configuration is split by grains.
Each grain is reponsible for one specific part of configuration.

Grains might read configuration from enviromental variables using python-dotenv.
Every variable read by grains is prefixed by grain name, i.e.:

    * django.py has variables prefixed with DJANGO\_
    * wagtail.py has variables prefixed with WAGTAIL\_
