from django.db import models

from wagtail.admin.panels import FieldPanel


class JumplinksMixin(models.Model):
    show_jumplinks = models.BooleanField(
        default=False,
        help_text=(
            "When this box is checked a summary of page contents shows at the "
            "top of the page. Not needed on short pages. Jumplinks are generated "
            "from all page components with heading 'Show in jumplinks' checked."
        ),
    )

    class Meta:
        abstract = True

    settings_panels = [FieldPanel("show_jumplinks")]
