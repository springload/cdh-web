from os.path import basename

from typed_environment_configuration import (
    BoolVariable,
    StringListVariable,
    StringVariable,
)

from app.settings.grains.paths import DJANGO_ROOT

# Project namespace
PROJECT = StringVariable("PROJECT").getenv()

# Site name:
SITE_NAME = basename(DJANGO_ROOT)

DEBUG = BoolVariable("DJANGO_DEBUG", default=False).getenv()
SECRET_KEY = StringVariable("APP_SECRET_KEY").getenv()
ALLOWED_HOSTS = StringListVariable("ADDRESSES", default="").getenv()

# Set the user model to a custom one, for ease of alteration later.
AUTH_USER_MODEL = "accounts.User"

INSTALLED_APPS = (
    "accounts",
    "components_base",
    "cms_test",
    "springkit",
    "django.contrib.admin",
    "django.contrib.auth",
    "django.contrib.contenttypes",
    "django.contrib.sessions",
    "django.contrib.messages",
    "django.contrib.staticfiles",
    "wagtail.embeds",
    "wagtail.sites",
    "wagtail.users",
    "wagtail.snippets",
    "wagtail.documents",
    "wagtail.images",
    "wagtail.search",
    "wagtail.admin",
    "wagtail",
    "modelcluster",
    "taggit",
    "pattern_library",
)


MIDDLEWARE = [
    "django.middleware.security.SecurityMiddleware",
    "app.middleware.PreviewCompatibilityUpdateCacheMiddleware",
    "django.middleware.http.ConditionalGetMiddleware",
    "django.middleware.common.CommonMiddleware",
    "django.contrib.sessions.middleware.SessionMiddleware",
    "django.middleware.csrf.CsrfViewMiddleware",
    "django.contrib.auth.middleware.AuthenticationMiddleware",
    "django.contrib.messages.middleware.MessageMiddleware",
    "django.middleware.clickjacking.XFrameOptionsMiddleware",
    "django.middleware.security.SecurityMiddleware",
    "csp.middleware.CSPMiddleware",
    "django.middleware.cache.FetchFromCacheMiddleware",
]
# X_FRAME_OPTIONS = "SAMEORIGIN"

DEFAULT_AUTO_FIELD = "django.db.models.AutoField"

# Name and email addresses of recipients
ADMINS = (("Tech-urgent", "tech-urgent@springload.co.nz"),)

ROOT_URLCONF = "app.urls"

WSGI_APPLICATION = "app.wsgi.application"

# we default to Pacific /Auckland
TIME_ZONE = "Pacific/Auckland"

CSRF_COOKIE_HTTPONLY = True
CSRF_COOKIE_SECURE = True
CSRF_TRUSTED_ORIGINS = ALLOWED_HOSTS

AUTH_PASSWORD_VALIDATORS = [
    {
        "NAME": "django.contrib.auth.password_validation.UserAttributeSimilarityValidator"
    },
    {
        "NAME": "django.contrib.auth.password_validation.MinimumLengthValidator",
        "OPTIONS": {"min_length": 12},
    },
    {"NAME": "django.contrib.auth.password_validation.CommonPasswordValidator"},
    {"NAME": "django.contrib.auth.password_validation.NumericPasswordValidator"},
]

# Security
SECURE_BROWSER_XSS_FILTER = True
SECURE_CONTENT_TYPE_NOSNIFF = True

PATTERN_LIBRARY = {
    # Groups of templates for the pattern library navigation. The keys
    # are the group titles and the values are lists of template name prefixes that will
    # be searched to populate the groups.
    "SECTIONS": (
        ("blocks", ["springkit/blocks"]),
        # ("pages", ["patterns/pages"]),
    ),
    # Configure which files to detect as templates.
    "TEMPLATE_SUFFIX": ".html",
    # Set which template components should be rendered inside of,
    # so they may use page-level component dependencies like CSS.
    "PATTERN_BASE_TEMPLATE_NAME": "components_base/base.html",
    # Any template in BASE_TEMPLATE_NAMES or any template that extends a template in
    # BASE_TEMPLATE_NAMES is a "page" and will be rendered as-is without being wrapped.
    "BASE_TEMPLATE_NAMES": [],
}
# silence warning caused by template tags overrides in `components_base`
SILENCED_SYSTEM_CHECKS = ["templates.E003"]
