from wagtail import blocks

from ..settings import get_setting
from . import HeadingBlock
from .cta import CTAButtonsBlock
from .image import UnsizedImageBlock


class FeatureBlock(blocks.StructBlock):
    heading = HeadingBlock(required=False)
    feature_text = blocks.RichTextBlock(
        max_length=400,
        features=[
            "bold",
            "document-link",
            "italic",
            "link",
            "ol",
            "ul",
        ],
    )
    image = UnsizedImageBlock()
    cta_buttons = CTAButtonsBlock(
        min_num=0,
        max_num=2,
        required=False,
    )

    class Meta:
        template = "springkit/blocks/feature/feature.html"
        label = "Feature"
        group = get_setting("BLOCK_GROUP_BODY_COPY")
        icon = "pick"
