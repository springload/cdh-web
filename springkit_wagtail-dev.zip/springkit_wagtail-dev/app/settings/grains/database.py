import dj_database_url
from typed_environment_configuration import StringVariable

DATABASE_URL = StringVariable("DATABASE_URL").getenv()

DATABASES = {"default": dj_database_url.parse(DATABASE_URL, conn_max_age=600)}
