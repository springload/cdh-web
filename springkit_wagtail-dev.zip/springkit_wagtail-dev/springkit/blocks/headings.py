from django.db import models

from wagtail import blocks

from ..settings import get_setting
from .jumplinks import JumplinkMixin


class HeadingBlockBase(blocks.StructBlock):
    heading = blocks.CharBlock(
        required=True,
        max_length=80,
    )

    class Meta:
        required = True

    def __init__(self, local_blocks=None, **kwargs):
        super().__init__(local_blocks, **kwargs)
        # if this heading block is not required, then set its heading field to be
        # optional
        if "required" in kwargs:
            self.child_blocks["heading"].field.required = kwargs["required"]


class HeadingBlockStructValue(blocks.StructValue):
    heading_level = "H2"

    @property
    def heading(self):
        return self.get("heading")


class HeadingBlock(HeadingBlockBase):
    """
    H2 block to use as a `heading` field block in other StructBlocks
    """

    class Meta:
        template = "springkit/blocks/heading/heading.html"
        label = "Heading"
        group = get_setting("BLOCK_GROUP_BODY_COPY")
        icon = "title"
        value_class = HeadingBlockStructValue


class JumplinkableH2Block(JumplinkMixin):
    heading = HeadingBlock()

    class Meta:
        template = "springkit/blocks/heading/jumplinkable_heading.html"
        label = "Heading"
        group = get_setting("BLOCK_GROUP_BODY_COPY")
        icon = "title"


class SubHeadingLevelChoices(models.TextChoices):
    H3 = "H3"
    H4 = "H4"
    H5 = "H5"


class SubHeadingBlock(HeadingBlockBase):
    class Meta:
        template = "springkit/blocks/heading/heading.html"
        label = "SubHeading"
        group = get_setting("BLOCK_GROUP_BODY_COPY")
        icon = "title"

    heading_level = blocks.ChoiceBlock(
        choices=SubHeadingLevelChoices.choices,
        default=SubHeadingLevelChoices.H3,
        required=True,
    )
