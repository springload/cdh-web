from typed_environment_configuration import StringVariable

from app.settings.grains.django import PROJECT
from app.settings.grains.environment import ENVIRONMENT

CACHE_URL = StringVariable("CACHE_URL").getenv()
CACHES = {
    "default": {
        "BACKEND": "django_redis.cache.RedisCache",
        "KEY_PREFIX": "-".join(
            [PROJECT, ENVIRONMENT]
        ),  # Add a prefix to distinguish huey entries and app entries
        "LOCATION": CACHE_URL,
        "OPTIONS": {"CLIENT_CLASS": "django_redis.client.DefaultClient"},
    }
}
