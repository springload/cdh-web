from wagtail import blocks
from wagtail.documents.blocks import DocumentChooserBlock

from ..settings import get_setting
from . import HeadingBlock
from .jumplinks import JumplinkMixin


class DownloadBlock(JumplinkMixin):
    heading = HeadingBlock()
    title = blocks.CharBlock(
        required=False,
        max_length=80,
        help_text=(
            "If left blank then the title of the document file will be used. "
            "(80 characters maximum)."
        ),
    )
    description = blocks.TextBlock(
        required=False,
        max_length=150,
        help_text=(
            "A description to display with the download file (150 characters "
            "maximum)."
        ),
    )
    document = DocumentChooserBlock(
        required=True,
        help_text="Will automatically show the file title, size and type.",
    )

    class Meta:
        template = "springkit/blocks/download/download.html"
        group = get_setting("BLOCK_GROUP_MEDIA")
        label = "Download"
        icon = "download"
