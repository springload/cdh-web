"""
Base level CSP.
We could consider locking down further, though with GTM on the site
it is a game of whack-a-mole for SCRIPT, IFRAME and IMG sources :(
with lots of scope for breakage from GTM pov.
"""
CSP_EXCLUDE_URL_PREFIXES = ("/admin/",)

CSP_DEFAULT_SRC = ["'self'"]

CSP_CHILD_SRC = ["'self'", "https:"]

CSP_CONNECT_SRC = ["'self'", "https:"]

CSP_FONT_SRC = [
    "'self'",
    "data:",
    # Google maps pulls in fonts from these
    "*.googleapis.com",
    "https://fonts.gstatic.com",
]

CSP_FRAME_ANCESTORS = ["'self'"]

CSP_FRAME_SRC = [
    "'self'",
    "https://player.vimeo.com",
    "https://www.youtube-nocookie.com",
]

CSP_IMG_SRC = ["'self'", "data:", "https:"]

CSP_MEDIA_SRC = ["'self'"]

CSP_OBJECT_SRC = ["'none'"]

CSP_SCRIPT_SRC = [
    "'self'",
    "'unsafe-inline'",  # For GTM, js/no-js script
    "'unsafe-eval'",  # javascript eval (used by Raven at least)
    "data:",
    "https:",
]

CSP_STYLE_SRC = ["'self'", "'unsafe-inline'", "https:"]

CSP_WORKER_SRC = ["'none'"]
