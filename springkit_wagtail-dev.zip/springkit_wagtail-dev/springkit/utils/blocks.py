from django.utils.encoding import force_str
from django.utils.text import capfirst


def block_group_and_label(child_block):
    """
    Sorting key to sort StreamField child blocks by group and label
    """
    name, field = child_block  # expecting tuple like ("paragraph", RichTextBlock(...))
    # if no 'label' use 'name' as per wagtail.blocks.base.Block.set_name logic
    label = field.label or capfirst(force_str(name).replace("_", " "))
    return field.meta.group, label  # sort by optional group first then label


def child_blocks(*args):
    """
    Return sorted list of wagtail blocks
    to be used as StreamField/StreamBlock child blocks
    each item is expected to be tuple like ("paragraph", RichTextBlock(...))

    Usage:
    body = StreamField(
        child_blocks(
            ("video", VideoServiceBlock()),
            ("page_alert", PageAlertBlock()),
        ),
    )

    Alternative Usage:
    body = StreamField(
        block_types=StreamBlock(
            child_blocks(
                ("video", VideoServiceBlock()),
                ("page_alert", PageAlertBlock()),
            ),
        )
    )
    """
    return sorted(args, key=block_group_and_label)
