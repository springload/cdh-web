# ruff: noqa: F401
from django.utils.module_loading import import_string

from ..settings import get_setting

if get_setting("BILINGUAL_HEADINGS"):
    from .headings_bilingual import BilingualHeadingBlock as HeadingBlock
    from .headings_bilingual import BilingualSubHeadingBlock as SubHeadingBlock
    from .headings_bilingual import JumplinkableH2Block
else:
    from .headings import HeadingBlock, JumplinkableH2Block, SubHeadingBlock

# import the link block that will be used by other Springkit blocks that have
# link fields
if DEFAULT_LINK_BLOCK := get_setting("DEFAULT_LINK_BLOCK"):
    LinkBlock = import_string(DEFAULT_LINK_BLOCK)
elif get_setting("BILINGUAL_LINKS"):
    from .link_bilingual import BilingualLinkBlock as LinkBlock
else:
    from .link import LinkBlock

from .accordion import AccordionBlock
from .cta import CTABlock
from .download import DownloadBlock
from .feature import FeatureBlock
from .image import ImageBlock
from .link_column import LinkColumnBlock
from .video import VideoBlock
