from rainbow_logging_handler import RainbowLoggingHandler


class ForceColorRainbowLoggingHandler(RainbowLoggingHandler):
    """
    Sometimes (read: under docker-compose) an output that
    does not appear to be a TTY actually is, and we want
    to force colored logs regardless. This wrapper allows
    us to trick the log handler into thinking it has a TTY,
    and thereby makes it log with colors
    """

    def __init__(self, *args, **kwargs):
        self.force_color = kwargs.pop("force_color", False)
        super().__init__(*args, **kwargs)

    @property
    def is_tty(self):
        """
        Returns true if the handler's stream is a terminal, or
        if we've force the handler to color logs anyway
        """
        if self.force_color:
            return True
        return getattr(self.stream, "isatty", lambda: False)()
