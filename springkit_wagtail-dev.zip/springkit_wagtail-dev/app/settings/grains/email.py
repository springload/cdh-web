from .. import PROJECT

EMAIL_BACKEND = "django_amazon_ses.EmailBackend"

AWS_SES_REGION = "ap-southeast-2"


# Default from address for CMS auto email messages (logs, errors..)
SERVER_EMAIL = "errors-%s@prdinfra.cloud" % PROJECT

# Default from address for CMS email messages to users (forgot password etc..)
DEFAULT_FROM_EMAIL = "%s@prdinfra.cloud" % PROJECT
