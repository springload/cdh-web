# ruff: noqa: F401
from .jumplinks import JumplinksMixin
from .titles import BilingualTitlesMixin, TitlesMixin
