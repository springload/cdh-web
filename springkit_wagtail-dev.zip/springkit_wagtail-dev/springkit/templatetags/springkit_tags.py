import logging

from django import template
from django.utils.text import slugify

from wagtail.blocks import BoundBlock, StructValue

from springkit.settings import get_setting

logger = logging.getLogger(__name__)

register = template.Library()


@register.inclusion_tag("springkit/includes/jumplinks.html")
def jumplinks(blocks):
    """
    Usage:
       {% jumplinks page.body %}
    """

    if not get_setting("JUMPLINKS_ENABLED"):
        return ""
    return {"jumplinks": make_jumplinks(blocks)}


def make_jumplinks(blocks):
    """
    Find blocks with `show_in_jumplinks` enabled and return a list of internal
    links to them.
    Adds a "jumplink_id" property to:
    - the heading field of each matching block if heading is a StructBlock, or
    - the block itself if the heading is a CharBlock
    """
    jumplinks = []
    seen = set()
    for block in blocks:
        heading_text, block_value = get_jumplinkable_heading_value(block)
        if not (heading_text and block_value):
            continue

        jumplink_id = slugify(heading_text)
        while jumplink_id in seen:
            # ensure no dupe link targets
            jumplink_id += "_"
        seen.add(jumplink_id)

        block_value["jumplink_id"] = jumplink_id
        jumplinks.append(
            {
                "text": heading_text,
                "target": jumplink_id,
            }
        )
    return jumplinks


def get_jumplinkable_heading_value(
    block: BoundBlock,
) -> tuple[str, StructValue] | tuple[None, None]:
    """
    Find the heading text for jumplinkable block value.
    Returns the heading text along with the StructValue to which the jumplink_id should
    be added to.
    """
    match block.value:
        case {
            "show_in_jumplinks": True,
            "heading": struct_val,
        } if hasattr(struct_val, "heading"):
            # heading field is a StructValue
            return struct_val.heading, struct_val

        case {"show_in_jumplinks": True, "heading": str(heading_text)}:
            # heading field is text field
            return heading_text, block.value

        case _:
            # not jumplink candidate
            return None, None
