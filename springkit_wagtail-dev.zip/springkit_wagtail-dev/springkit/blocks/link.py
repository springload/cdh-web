from django.utils.functional import cached_property

from wagtail import blocks

from ..settings import get_setting


class LinkStructValue(blocks.StructValue):
    @cached_property
    def url(self):
        if page := self.get("page"):
            return page.get_url()
        elif link_url := self.get("link_url"):
            return link_url

    @cached_property
    def text(self):
        if link_text := self.get("link_text"):
            return link_text
        elif page := self.get("page"):
            return page.title


class InternalLinkBlock(blocks.StructBlock):
    page = blocks.PageChooserBlock()
    link_text = blocks.CharBlock(
        required=False,
        help_text="Override the link text taken from the target Page title",
    )

    class Meta:
        template = "springkit/blocks/link/link.html"
        label = "Internal link"
        icon = "link"
        value_class = LinkStructValue


class ExternalLinkBlock(blocks.StructBlock):
    link_url = blocks.URLBlock(label="URL")
    link_text = blocks.CharBlock()

    class Meta:
        template = "springkit/blocks/link/link.html"
        label = "External link"
        icon = "link-external"
        value_class = LinkStructValue


class LinkBlock(blocks.StreamBlock):
    internal_link = InternalLinkBlock()
    external_link = ExternalLinkBlock()

    def render_basic(self, value, context=None):
        """Override to avoid <div> container"""
        return value[0].render(context=context)

    class Meta:
        label = "Link"
        group = get_setting("BLOCK_GROUP_LINKS_TILES")
        icon = "link"
        max_num = 1
