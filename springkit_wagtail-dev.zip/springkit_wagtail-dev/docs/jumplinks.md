# Jumplinks

Jumplinks makes available an "On this page" menu of links to block content
within a page.

To add Jumplinks functionality to a page use the `JumplinksMixin` Page model
mixin and add the `jumplinks` template tag to your template.

```python
from springkit.blocks import JumplinkableH2Block
from springkit.models.mixins import JumplinksMixin

class ContentPage(JumplinksMixin, Page):
    body = StreamField(
        [
            ("heading", JumplinkableH2Block()),
            ("richtext", RichTextBlock()),
        ],
        use_json_field=True,
    )

    content_panels = Page.content_panels + [FieldPanel("body")]
    # Add Show jumplinks setting
    settings_panels = Page.settings_panels + JumplinksMixin.settings_panels
```

```django
{% load wagtailcore_tags springkit_tags %}
{% block content %}
  {% if page.show_jumplinks %}
    {# takes a streamfield as argument #}
    {% jumplinks page.body %}
  {% endif %}
  {% for block in page.body %}
    {% include_block block %}
  {% endfor %}
{% endblock %}
```


The block mixin `blocks.jumplinks.JumplinkMixin` provides a "Show in jumplinks"
option to subclasses which enables them to be added to the jumplinks menu.
`JumplinkMixin` subclasses are expected to provide a `heading` field.

If the Django setting `JUMPLINKS_ENABLED` is False (default True), then no
Jumplink option will be added to blocks and jumplinks will be disabled.

