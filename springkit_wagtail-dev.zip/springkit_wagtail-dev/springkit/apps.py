from django.apps import AppConfig


class SpringkitConfig(AppConfig):
    default_auto_field = "django.db.models.AutoField"
    name = "springkit"
