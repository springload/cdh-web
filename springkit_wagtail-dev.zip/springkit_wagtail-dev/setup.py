import os

from setuptools import setup

# allow setup.py to be run from any path
os.chdir(os.path.normpath(os.path.join(os.path.abspath(__file__), os.pardir)))

# with open(os.path.join(os.path.dirname(__file__), 'README.md')) as readme:
#     README = readme.read()

# Package dependencies
install_requires = [
    "wagtail>=4.1,<6.0",
]

# Documentation dependencies
documentation_extras = []

setup(
    name="springkit",
    version=__import__("springkit").__version__,
    package_dir={"springkit": "springkit"},
    include_package_data=True,
    description="Springkit Wagtail components",
    # long_description=README,
    # long_description_content_type='text/markdown',
    # url='https://github.com/ibrahimawadhamid/wagtail_blocks/',
    author="Springload",
    author_email="tech@springload.co.nz",
    classifiers=[
        "Development Status :: 5 - Production/Stable",
        "Environment :: Web Environment",
        "Framework :: Django",
        "Framework :: Django :: 3.2",
        "Framework :: Django :: 4.1",
        "Framework :: Django :: 4.2",
        "Framework :: Wagtail",
        "Framework :: Wagtail :: 4",
        "Framework :: Wagtail :: 5",
        "Intended Audience :: Developers",
        # 'License :: OSI Approved :: MIT License',
        "Operating System :: OS Independent",
        "Programming Language :: Python",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Topic :: Internet :: WWW/HTTP",
        "Topic :: Internet :: WWW/HTTP :: Dynamic Content",
        "Topic :: Software Development",
    ],
    install_requires=install_requires,
    extras_require={"docs": documentation_extras},
)
