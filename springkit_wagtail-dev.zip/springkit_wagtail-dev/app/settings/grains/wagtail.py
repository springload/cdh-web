from .django import ALLOWED_HOSTS

LOGIN_URL = "wagtailadmin_login"
LOGIN_REDIRECT_URL = "wagtailadmin_home"

WAGTAIL_SITE_NAME = "springkit"

# Limit image upload size due to RAM constraints on containers
WAGTAILIMAGES_MAX_IMAGE_PIXELS = 30 * 1000**2  # 30MP size limit

WAGTAILIMAGES_WEBP_QUALITY = 60

# WAGTAILADMIN_BASE_URL is only used in emails from the wagtailadmin that
# are sent in a non-request-context, fixes moderation emails
# according to https://github.com/wagtail/wagtail/issues/826
if ALLOWED_HOSTS and ALLOWED_HOSTS[0] != "*":
    WAGTAILADMIN_BASE_URL = ALLOWED_HOSTS[0]

WAGTAIL_ENABLE_UPDATE_CHECK = "lts"
