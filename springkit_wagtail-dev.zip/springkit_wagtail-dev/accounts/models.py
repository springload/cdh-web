from django.contrib.auth.models import AbstractUser, UserManager


class CaseInsensitiveUserManager(UserManager):
    def get_by_natural_key(self, username):
        case_insensitive_username_field = "{}__iexact".format(self.model.USERNAME_FIELD)
        return self.get(**{case_insensitive_username_field: username})


class User(AbstractUser):
    """
    A simple User model that makes username lookups
    case-insensitive, because that's what most people
    expect (IMO).

    Also makes it easy to make changes to the users later
    without having do a tricky migration.
    """

    objects = CaseInsensitiveUserManager()
