import sys

__all__ = ["LOGGING"]  # don't import DEV_LOGGING by default

LOGGING = {
    "version": 1,
    "disable_existing_loggers": False,
    "formatters": {
        "verbose": {
            "format": "%(asctime)s | %(levelname)s [%(name)s.%(filename)s:%(lineno)s] %(message)s",
            "datefmt": "%Y-%m-%d %H:%M:%S%z",
        },
        "simple": {"format": "%(levelname)s %(message)s"},
        "json": {
            "()": "pythonjsonlogger.jsonlogger.JsonFormatter",
            "fmt": "%(asctime)s %(levelname)s %(message)s %(name)s %(filename)s %(lineno)s %(pathname)s %(funcName)s",
        },
    },
    "handlers": {
        "stdout": {
            "level": "DEBUG",
            "class": "logging.StreamHandler",
            "formatter": "json",
        },
    },
    "loggers": {
        "django": {"handlers": ["stdout"], "propagate": True, "level": "ERROR"},
        "wagtail": {"handlers": ["stdout"], "propagate": True, "level": "INFO"},
        "app": {"handlers": ["stdout"], "propagate": True, "level": "INFO"},
        "accounts": {"handlers": ["stdout"], "propagate": True, "level": "INFO"},
        "cms_test": {"handlers": ["stdout"], "propagate": True, "level": "INFO"},
    },
}

DEV_LOGGING = {
    "version": 1,
    "disable_existing_loggers": False,
    "formatters": {},
    "handlers": {
        "dev_console": {
            "level": "DEBUG",
            "class": "app.logging.ForceColorRainbowLoggingHandler",
            "stream": sys.stderr,
            "force_color": True,
        }
    },
    "root": {  # using root logger to catch and log all interesting messages
        "level": "WARNING",
        "handlers": ["dev_console"],
    },
    "loggers": {
        "django": {"handlers": ["dev_console"], "propagate": False, "level": "INFO"},
        "wagtail": {"handlers": ["dev_console"], "propagate": False, "level": "INFO"},
        "django.db.backends": {
            "handlers": ["dev_console"],
            "propagate": False,
            "level": "INFO",
        },
        "django.template": {
            "handlers": ["dev_console"],
            "propagate": False,
            "level": "INFO",
        },
        "app": {"handlers": ["dev_console"], "propagate": False, "level": "DEBUG"},
        "accounts": {"handlers": ["dev_console"], "propagate": False, "level": "DEBUG"},
        "cms_test": {"handlers": ["dev_console"], "propagate": False, "level": "DEBUG"},
        # add section for every new project app
        # 'app_name_here': {
        #     'handlers': ['dev_console'],
        #     'propagate': False,
        #     'level': 'DEBUG',
        # },
    },
}
