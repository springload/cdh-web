> Commonly used Wagtail components used on Springload projects

## Important links

| Important links :book:            |
|---------------------------------- |
| Documentation in [`docs/`](docs/) |
|[Dev site](https://springkit.dev.springload.nz) (http://localhost:55980)|
|[Notion page](https://www.notion.so/springload/Springkit-9e3b4cbf3fc9404bab661292dede94d4)|


# Development

Code for the Springkit package resides in [./springkit](springkit) with the
package build configuration in [./setup.py](setup.py) and
[MANIFEST.in](MANIFEST.in).  Everything outside these files exists to help local
development and testing.

## Local Wagtail CMS
To test out Springkit blocks in a CMS environment run `docker-compose up` and
visit
[https://springkit.dev.springload.nz](https://springkit.dev.springload.nz).

The models and templates for this CMS are in the `cms_test` folder.


## Statically rendered components 
In addition to using the CMS, you can view statically rendered versions of
Springkit components at
[https://springkit.dev.springload.nz/components/](https://springkit.dev.springload.nz/components/).

This allows for component templates to be worked on independently of any python code.

It uses [django-pattern-library](https://torchbox.github.io/django-pattern-library/). The scaffolding for this view is defined in [./components_base](components_base)

Content for rendered components is defined in `yaml` files which sit side by
side with the component template. For example, if the Springkit block `VideoBlock`
has a template at `springkit/templates/springkit/blocks/video/video.html`, then the
`yaml` describing the render context would be at
`springkit/templates/springkit/blocks/video/video.yaml`. See [Template
context](https://torchbox.github.io/django-pattern-library/guides/defining-template-context/)
for more detail.

Note that the pattern-library framework does not handle having multiple
configurations (context variations) for one template. See the
`templates/springkit/blocks/image/` folder for example of a workaround.


## Building the Springkit package

``` sh
python setup.py sdist
```
This will generate a pip installable package into `dist/` (e.g.
`dist/springkit-0.0.1.tar.gz`) from the code contained in `springkit`.

