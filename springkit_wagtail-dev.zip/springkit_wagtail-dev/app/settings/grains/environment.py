"""
Environment Settings
"""

from typed_environment_configuration import StringVariable

# Application environment i.e. development, production, etc.
ENVIRONMENT = StringVariable("ENVIRONMENT").getenv()
IS_PROD = ENVIRONMENT.lower() in ["production"]

# Environment "class" -- "production" for hosted environments, nonprod otherwise
SERVER_ENV = StringVariable("DJANGO_SERVER_ENV", default="Nonprod").getenv()

# Code release, usually short commit hash
APPLICATION_VERSION = StringVariable("APPLICATION_VERSION").getenv()
