from django.forms.utils import ErrorList

from wagtail import blocks
from wagtail.blocks.struct_block import StructBlockValidationError

from ..settings import get_setting
from .headings import HeadingBlockStructValue, SubHeadingLevelChoices
from .jumplinks import JumplinkMixin


class BilingualHeadingBlockBase(blocks.StructBlock):
    heading_en = blocks.CharBlock(
        label="English language Heading",
        required=False,
        max_length=80,
    )
    heading_mi = blocks.CharBlock(
        label="Te reo Māori Heading",
        required=False,
        max_length=90,
    )

    def clean(self, value):
        if (
            self.meta.required
            and not value.get("heading_en")
            and not value.get("heading_mi")
        ):
            ERROR = ErrorList(["Please enter an English or Te reo Māori heading"])
            raise StructBlockValidationError(
                block_errors={
                    "heading_en": ERROR,
                    "heading_mi": ERROR,
                }
            )
        return super().clean(value)


class BilingualHeadingStructValue(HeadingBlockStructValue):
    @property
    def heading(self):
        """
        Provide a heading value to use for jumplinks
        """
        return self.get("heading_en") or self.get("heading_mi")


class BilingualHeadingBlock(BilingualHeadingBlockBase):
    """
    Bilingual H2 block to use as `heading` field block in other StructBlocks
    """

    class Meta:
        template = "springkit/blocks/heading/heading_bilingual.html"
        label = "Heading"
        group = get_setting("BLOCK_GROUP_BODY_COPY")
        icon = "title"
        required = True
        value_class = BilingualHeadingStructValue


class JumplinkableH2Block(JumplinkMixin):
    """
    Standalone, bilingual, jumplinkable H2 heading block
    """

    heading = BilingualHeadingBlock()

    class Meta:
        template = "springkit/blocks/heading/jumplinkable_heading.html"
        label = "Heading"
        group = get_setting("BLOCK_GROUP_BODY_COPY")
        icon = "title"


class BilingualSubHeadingBlock(BilingualHeadingBlockBase):
    """
    Bilingual H3-H5 heading block
    """

    class Meta:
        template = "springkit/blocks/heading/heading_bilingual.html"
        label = "SubHeading"
        group = get_setting("BLOCK_GROUP_BODY_COPY")
        icon = "title"

    heading_level = blocks.ChoiceBlock(
        choices=SubHeadingLevelChoices.choices,
        default=SubHeadingLevelChoices.H3,
        required=True,
    )
