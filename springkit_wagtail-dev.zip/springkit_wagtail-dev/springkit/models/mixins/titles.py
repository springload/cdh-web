from django.db import models
from django.utils.functional import cached_property

from wagtail.admin.panels import FieldPanel, MultiFieldPanel, TitleFieldPanel

from springkit.utils.model import get_first_of


class TitlesMixin(models.Model):
    """
    Model mixin provides nav title
    """

    short_title = models.CharField(max_length=80, blank=True)

    class Meta:
        abstract = True

    @cached_property
    def nav_title(self):
        return get_first_of(self, "short_title", "title")

    promote_panels = [
        FieldPanel(
            "short_title",
            help_text="Appears in breadcrumbs, tiles, menu items, etc.",
        )
    ]


class BilingualTitlesMixin(TitlesMixin):
    """
    Model mixin provides Te reo title and bilingual nav titles
    """

    title_mi = models.CharField(
        verbose_name="Page title in Te reo Māori",
        max_length=100,
        blank=True,
    )

    short_title_mi = models.CharField(
        verbose_name="Te reo Māori short title",
        max_length=90,
        blank=True,
    )

    class Meta:
        abstract = True

    @cached_property
    def nav_title_mi(self):
        return get_first_of(self, "short_title_mi", "title_mi")

    content_panels = [
        MultiFieldPanel([TitleFieldPanel("title"), FieldPanel("title_mi")])
    ]
    promote_panels = [
        MultiFieldPanel(
            [FieldPanel("short_title"), FieldPanel("short_title_mi")],
            "For navigation titles",
            help_text="Appears in breadcrumbs, tiles, menu items, etc.",
        )
    ]
