import logging

import sentry_sdk
from sentry_sdk.integrations.django import DjangoIntegration
from sentry_sdk.integrations.logging import LoggingIntegration
from typed_environment_configuration import StringVariable

from app.settings.grains.environment import APPLICATION_VERSION, ENVIRONMENT

SENTRY_RELEASE = APPLICATION_VERSION
SENTRY_ENVIRONMENT = ENVIRONMENT
SENTRY_DSN_BED = StringVariable("SENTRY_DSN_BED", default="").getenv()
SENTRY_DSN_CSP_BED = StringVariable("SENTRY_DSN_CSP_BED", default="").getenv()
SENTRY_DSN_FED = StringVariable("SENTRY_DSN_FED", default="").getenv()


sentry_logging = LoggingIntegration(level=logging.INFO, event_level=logging.ERROR)

sentry_sdk.init(
    dsn=SENTRY_DSN_BED,
    integrations=[DjangoIntegration(), sentry_logging],
    release=SENTRY_RELEASE,
    environment=SENTRY_ENVIRONMENT,
)

# Add on release and env to CSP report-uri
CSP_REPORT_URI = f"{SENTRY_DSN_CSP_BED}&sentry_release={SENTRY_RELEASE}&sentry_environment={SENTRY_ENVIRONMENT}"
