"""
Put any Springkit settings in here that you want to have default/fallback
values.
Blocks which require settings should fetch the setting using
`get_setting(SETTING_NAME)`, which will return the default defined here if has
not been set on the projects Django settings
"""
import logging
from typing import Literal

from django.conf import settings

logger = logging.getLogger(__name__)

SPRINGKIT_STANDARD_RICH_TEXT_FEATURES = [
    "bold",
    "italic",
    "superscript",
    "link",
    "document-link",
    "ol",
    "ul",
    "h3",
    "h4",
    "h5",
]
SPRINGKIT_SIMPLE_RICH_TEXT_FEATURES = [
    "bold",
    "link",
    "document-link",
]

# whether to enable Add to Jumplinks option on blocks that use the Jumplinks mixin.
JUMPLINKS_ENABLED: bool = True

BILINGUAL_HEADINGS: bool = True

# Blocks that have a link field have bilingual text by default
BILINGUAL_LINKS: bool = True

# Set the the required-ness of bilingual link text. Default is "en". Add "mi" to
# this list if you want both fields to be required
BILINGUAL_LINKS_REQUIRED_LANGS: list[Literal["en", "mi"], ...] = ["en"]

# Optional: if the default Springkit block does not work for you, then set a
# path a custom link block to be used by Springkit blocks that have link fields.
# example: DEFAULT_LINK_BLOCK = "core.blocks.link.MyLink"
DEFAULT_LINK_BLOCK: str | None = None

# Block group labels. If your project uses Block groups then you can override these
# to match your groups (or use these ones). If your project does not use groups,
# set these to empty string.
BLOCK_GROUP_BODY_COPY = "Body copy components"
BLOCK_GROUP_MEDIA = "Images and media"
BLOCK_GROUP_LINKS_TILES = "Links and tiles"


def get_setting(setting_name: str, warn_if_not_set=True):
    try:
        return getattr(settings, setting_name)
    except AttributeError:
        pass
    # Distinguish between non-truthy setting values and settings that are simply unset
    if (default_setting := globals().get(setting_name, ...)) is not ...:
        return default_setting
    if warn_if_not_set:
        logger.warn(f"Asked for setting '{setting_name}', which is not defined")
