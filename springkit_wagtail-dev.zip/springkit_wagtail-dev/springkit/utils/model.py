def get_first_of(instance, *fields, default=None):
    """
    Return the first non empty value from fields on `instance` - or `default`
    """
    return next(
        (value for field in fields if (value := getattr(instance, field, ""))), default
    )
