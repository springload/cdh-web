import requests
from typed_environment_configuration import StringVariable

from django.core.exceptions import ImproperlyConfigured

from .django import ALLOWED_HOSTS


def _probe_aws_ip():
    try:
        ec2_private_ip = requests.get(
            "http://169.254.169.254/latest/meta-data/local-ipv4", timeout=3
        ).text
    except requests.exceptions.RequestException as e:
        raise ValueError("Could not get EC2 private ip address: {}".format(e))
    else:
        if not ec2_private_ip:
            raise ValueError(
                "Could not get EC2 private ip address: ec2_private_ip={!r}".format(
                    ec2_private_ip
                )
            )
        return ec2_private_ip


ALLOWED_HOSTS.append(_probe_aws_ip())

AWS = True

"""S3 Settings"""

# Actual bucket name for storage
AWS_STORAGE_BUCKET_NAME = StringVariable("AWS_STORAGE_BUCKET_NAME", default="").getenv()
# Custom domain for public access to storage
AWS_S3_CUSTOM_DOMAIN = StringVariable("AWS_S3_CUSTOM_DOMAIN", default="").getenv()

AWS_S3_OBJECT_PARAMETERS = {"CacheControl": "public, max-age=900"}

DEFAULT_FILE_STORAGE = "app.s3utils.MediaRootS3BotoStorage"
STATICFILES_STORAGE = "app.s3utils.StaticRootS3BotoStorage"

if not AWS_STORAGE_BUCKET_NAME:
    raise ImproperlyConfigured(
        "Wrong AWS_STORAGE_BUCKET_NAME={!r} env variable".format(
            AWS_STORAGE_BUCKET_NAME
        )
    )

if not AWS_S3_CUSTOM_DOMAIN:
    AWS_S3_CUSTOM_DOMAIN = "{}.s3-ap-southeast-2.amazonaws.com".format(
        AWS_STORAGE_BUCKET_NAME
    )

STATIC_URL = "https://%s/static/" % AWS_S3_CUSTOM_DOMAIN
MEDIA_URL = "https://%s/media/" % AWS_S3_CUSTOM_DOMAIN

AWS_S3_FILE_OVERWRITE = False
