from wagtail import blocks

from . import HeadingBlock, LinkBlock
from .jumplinks import JumplinkMixin


class LinkColumnBlock(JumplinkMixin):
    heading = HeadingBlock()
    links = blocks.ListBlock(LinkBlock, max_num=7)

    class Meta:
        template = "springkit/blocks/link_column/link_column.html"
        label = "Link column"
