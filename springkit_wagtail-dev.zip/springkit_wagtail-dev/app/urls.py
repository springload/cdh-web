import os

from django.conf import settings
from django.conf.urls.static import static
from django.contrib import admin
from django.urls import include, path, re_path
from django.views.generic import TemplateView
from django.views.static import serve

from wagtail import urls as wagtail_urls
from wagtail.admin import urls as wagtailadmin_urls
from wagtail.contrib.sitemaps.views import sitemap
from wagtail.documents import urls as wagtaildocs_urls
from wagtail.images import urls as wagtailimages_urls
from wagtail.search.signal_handlers import (
    register_signal_handlers as wagtailsearch_register_signal_handlers,
)

admin.autodiscover()


# Register search signal handlers
wagtailsearch_register_signal_handlers()


urlpatterns = [
    path("django-admin/", admin.site.urls),
    path("admin/", include(wagtailadmin_urls)),
    path("documents/", include(wagtaildocs_urls)),
    path("images/", include(wagtailimages_urls)),
    path("sitemap.xml", sitemap),
    path("components/", include("pattern_library.urls")),
]


if settings.ENVIRONMENT == "production":
    robots_txt = "robots_prod.txt"
else:
    robots_txt = "robots_dev.txt"
urlpatterns.append(
    path(
        "robots.txt",
        TemplateView.as_view(template_name=robots_txt, content_type="text/plain"),
    )
)


if settings.DEBUG:
    # initialize debug_toolbar
    import debug_toolbar

    urlpatterns.append(path("__debug__/", include(debug_toolbar.urls)))

    # error pages for testing
    urlpatterns.append(path("404/", TemplateView.as_view(template_name="404.html")))
    urlpatterns.append(path("500/", TemplateView.as_view(template_name="500.html")))

    urlpatterns += static(
        settings.MEDIA_URL + "images/",
        document_root=os.path.join(settings.MEDIA_ROOT, "images"),
    )

else:
    urlpatterns.append(
        re_path(
            r"^static/(?P<path>.*)$", serve, {"document_root": settings.STATIC_ROOT}
        )
    )

# urlpatterns.append(
#     path(
#         "favicon.ico",
#         serve,
#         {
#             "document_root": os.path.join(settings.DJANGO_ROOT, "core", "static"),
#             "path": "favicon.ico",
#         },
#     )
# )

# serve svg files from core/static directory because cross-origin is not allowed
# in SVG <use> URLs
# urlpatterns.append(
#     re_path(
#         r"^static-svg/(?P<path>.*)$", serve, {"document_root": settings.STATIC_SVG_ROOT}
#     )
# )

urlpatterns.append(path("", include(wagtail_urls)))  # this must always be the last one
