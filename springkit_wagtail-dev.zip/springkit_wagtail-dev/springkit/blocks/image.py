from django.db import models

from wagtail import blocks
from wagtail.images.blocks import ImageChooserBlock

from ..settings import get_setting


class UnsizedImageBlock(blocks.StructBlock):
    class Meta:
        template = "springkit/blocks/image/image.html"
        label = "Image"
        group = get_setting("BLOCK_GROUP_MEDIA")
        icon = "image"

    title = blocks.CharBlock(
        help_text="A short title for the media within the page.",
        required=False,
        max_length=80,
    )

    caption = blocks.RichTextBlock(
        features=get_setting("SPRINGKIT_SIMPLE_RICH_TEXT_FEATURES"),
        help_text="A short caption for the image.",
        required=False,
        max_length=180,
    )

    credit = blocks.RichTextBlock(
        features=get_setting("SPRINGKIT_SIMPLE_RICH_TEXT_FEATURES"),
        help_text="A credit line or attribution for the image.",
        required=False,
        max_length=80,
    )

    alt_text = blocks.CharBlock(
        help_text="Alternative text in case the image can't be displayed.",
        required=False,
        max_length=80,
    )

    image = ImageChooserBlock(
        label="Image",
        required=True,
    )


class ImageBlock(UnsizedImageBlock):
    """ImageBlock - with size option"""

    class ImageSizeOption(models.TextChoices):
        FULL = "full", "full width"
        HALF = "half", "1/2 width"
        ONE_THIRD = "one-third", "1/3 width"

    size = blocks.ChoiceBlock(
        choices=ImageSizeOption.choices,
        default=ImageSizeOption.FULL,
        required=True,
        label="Image Size",
        help_text="Image sizes refer to desktop widths only. On mobile, images will show full width.",
    )
