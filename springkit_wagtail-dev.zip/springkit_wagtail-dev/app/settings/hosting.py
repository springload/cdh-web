from .base import *
from .grains.aws import *
from .grains.email import *
from .grains.sentry import *

# Analytics stuff
GOOGLE_TAG_MANAGER = None
GOOGLE_ANALYTICS_KEY = None

# Server environment
SERVER_ENV = "Production"

SESSION_COOKIE_SECURE = True
SESSION_COOKIE_HTTPONLY = True
# only for Django >= 2.1 SESSION_COOKIE_SAMESITE = "Lax"

CSRF_COOKIE_SECURE = True
CSRF_COOKIE_HTTPONLY = True
# only for Django >= 2.1 CSRF_COOKIE_SAMESITE = "Lax"

SECURE_HSTS_SECONDS = 31536000

if AWS_S3_CUSTOM_DOMAIN:
    CSP_FONT_SRC.append("https://%s/" % AWS_S3_CUSTOM_DOMAIN)
    # Following are only really necessary if `https:` is removed from them
    CSP_SCRIPT_SRC.append("https://%s/" % AWS_S3_CUSTOM_DOMAIN)
    CSP_STYLE_SRC.append("https://%s/" % AWS_S3_CUSTOM_DOMAIN)
    CSP_IMG_SRC.append("https://%s/" % AWS_S3_CUSTOM_DOMAIN)
