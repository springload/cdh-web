from wagtail import blocks

from ..settings import get_setting
from .link import ExternalLinkBlock, InternalLinkBlock


class CTAButtonBase(blocks.StructBlock):
    """
    Base block overriding LinkBlock `link_text` field constraints
    """

    link_text = blocks.CharBlock(label="Button text", required=True, max_length=40)

    class Meta:
        template = "springkit/shared/button.html"


class CTAExternalLinkBlock(CTAButtonBase, ExternalLinkBlock):
    pass


class CTAInternalLinkBlock(CTAButtonBase, InternalLinkBlock):
    pass


class CTAButtonsBlock(blocks.StreamBlock):
    internal_link = CTAInternalLinkBlock()
    external_link = CTAExternalLinkBlock()

    class Meta:
        template = "springkit/shared/buttons.html"


class CTABlock(blocks.StructBlock):
    """
    Two button block with introduction
    """

    introduction = blocks.TextBlock(
        required=False,
        help_text=(
            "Short introduction to the action you want users to take. Ideal: 80 "
            "characters or less (Max: 100 characters)."
        ),
        max_length=100,
    )
    cta_buttons = CTAButtonsBlock(
        min_num=1,
        max_num=2,
    )

    class Meta:
        template = "springkit/blocks/cta/cta.html"
        label = "Call to action"
        group = get_setting("BLOCK_GROUP_LINKS_TILES")
        icon = "link"
