from wagtail.admin.panels import FieldPanel
from wagtail.blocks import RichTextBlock
from wagtail.fields import StreamField
from wagtail.models import Page

from springkit.blocks import (
    AccordionBlock,
    CTABlock,
    DownloadBlock,
    FeatureBlock,
    ImageBlock,
    JumplinkableH2Block,
    LinkBlock,
    LinkColumnBlock,
    SubHeadingBlock,
    VideoBlock,
)
from springkit.models.mixins import BilingualTitlesMixin, JumplinksMixin


class ContentPage(JumplinksMixin, BilingualTitlesMixin, Page):
    body = StreamField(
        [
            ("accordion", AccordionBlock()),
            ("cta", CTABlock()),
            ("body_copy", RichTextBlock()),
            ("download", DownloadBlock()),
            ("feature", FeatureBlock()),
            ("heading", JumplinkableH2Block()),
            ("subheading", SubHeadingBlock()),
            ("image", ImageBlock()),
            ("link", LinkBlock()),
            ("link_column", LinkColumnBlock()),
            ("video", VideoBlock()),
        ],
        use_json_field=True,
    )

    content_panels = BilingualTitlesMixin.content_panels + [FieldPanel("body")]
    promote_panels = Page.promote_panels + BilingualTitlesMixin.promote_panels
    settings_panels = Page.settings_panels + JumplinksMixin.settings_panels
