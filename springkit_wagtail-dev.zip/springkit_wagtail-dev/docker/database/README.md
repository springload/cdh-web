# database

The container runs PostgreSQL server.
Any `.sql`, `.sql.gz` or `.sh` script in this folder will be executed on database container creation. 

Ask DevOps team to provide `initdb.sql.gz` file and place it into `docker/database` directory
