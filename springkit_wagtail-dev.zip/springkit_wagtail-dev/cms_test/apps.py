from django.apps import AppConfig


class CmsTestConfig(AppConfig):
    default_auto_field = "django.db.models.AutoField"
    name = "cms_test"
